<?php
// api/events.php
session_start();
header('Content-Type: application/json');

$room = $_GET['room'] ?? 'default';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $body = file_get_contents('php://input');
    $arr = json_decode($body, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        http_response_code(400);
        echo json_encode(["error" => "invalid_json"]);
        exit;
    }
    if (!isset($_SESSION["events_$room"])) {
        $_SESSION["events_$room"] = [];
    }
    $_SESSION["events_$room"][] = $arr;
    echo json_encode(["status" => "ok"]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $events = $_SESSION["events_$room"] ?? [];
    echo json_encode($events);
    // Vaciar después de leer para simular “stream”
    $_SESSION["events_$room"] = [];
    exit;
}

http_response_code(405);
echo json_encode(["error" => "method_not_allowed"]);
