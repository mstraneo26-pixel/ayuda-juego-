<?php
header('Content-Type: application/json');
session_start();

$action = $_GET['action'] ?? '';
$partidas_file = __DIR__ . '/../data/partidas.json';

// Asegurar que existe el directorio data
if (!file_exists(__DIR__ . '/../data')) {
    mkdir(__DIR__ . '/../data', 0777, true);
}

// Cargar partidas existentes
function cargarPartidasGuardadas() {
    global $partidas_file;
    if (file_exists($partidas_file)) {
        return json_decode(file_get_contents($partidas_file), true) ?? [];
    }
    return [];
}

// Guardar partidas al archivo
function guardarPartidasArchivo($partidas) {
    global $partidas_file;
    file_put_contents($partidas_file, json_encode($partidas, JSON_PRETTY_PRINT));
}

switch ($action) {
    case 'listar':
        $partidas = cargarPartidasGuardadas();
        echo json_encode(array_values($partidas));
        break;

    case 'guardar':
        $body = file_get_contents('php://input');
        $partida = json_decode($body, true);
        if (!$partida || !isset($partida['id'])) {
            http_response_code(400);
            echo json_encode(['error' => 'datos_invalidos']);
            exit;
        }
        $partidas = cargarPartidasGuardadas();
        $partidas[$partida['id']] = $partida;
        guardarPartidasArchivo($partidas);
        echo json_encode(['status' => 'ok']);
        break;

    case 'cargar':
        $id = $_GET['id'] ?? '';
        $partidas = cargarPartidasGuardadas();
        if (!isset($partidas[$id])) {
            http_response_code(404);
            echo json_encode(['error' => 'no_encontrada']);
            exit;
        }
        echo json_encode($partidas[$id]);
        break;

    case 'eliminar':
        $id = $_GET['id'] ?? '';
        $partidas = cargarPartidasGuardadas();
        if (isset($partidas[$id])) {
            unset($partidas[$id]);
            guardarPartidasArchivo($partidas);
        }
        echo json_encode(['status' => 'ok']);
        break;

    default:
        http_response_code(400);
        echo json_encode(['error' => 'accion_invalida']);
}