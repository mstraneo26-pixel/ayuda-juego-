<?php
// api/reset.php
session_start();
unset($_SESSION['carcassonne_state']);
header('Content-Type: application/json');
echo json_encode(["status" => "reset"]);
