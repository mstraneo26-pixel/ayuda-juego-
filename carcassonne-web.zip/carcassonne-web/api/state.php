<?php
// api/state.php
session_start();
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if (isset($_SESSION['carcassonne_state'])) {
        echo $_SESSION['carcassonne_state'];
    } else {
        echo json_encode(["message" => "no_state"]);
    }
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $body = file_get_contents('php://input');
    json_decode($body);
    if (json_last_error() !== JSON_ERROR_NONE) {
        http_response_code(400);
        echo json_encode(["error" => "invalid_json"]);
        exit;
    }
    $_SESSION['carcassonne_state'] = $body;
    echo json_encode(["status" => "saved"]);
    exit;
}

http_response_code(405);
echo json_encode(["error" => "method_not_allowed"]);
