// game.js
import { BASE_DECK, rotateTile, cloneTile, shuffleDeck, edgesMatch } from './tiles.js';

const GRID_SIZE = 13;
const CENTER = Math.floor(GRID_SIZE / 2);

const state = {
  grid: createEmptyGrid(GRID_SIZE),
  deck: [],
  players: [
    { id: 0, name: 'Jugador 1', score: 0, meeples: 7 },
    { id: 1, name: 'Jugador 2', score: 0, meeples: 7 },
  ],
  currentPlayer: 0,
  currentTile: null,
  useLocalStorage: true,
  legalPositions: new Set(),
  history: [],
  areas: {},
  nextAreaId: 1,
  net: { connected: false, roomId: null }
};

function createEmptyGrid(n) {
  return Array.from({ length: n }, () => Array(n).fill(null));
}

function newGame() {
  state.grid = createEmptyGrid(GRID_SIZE);
  state.deck = shuffleDeck(BASE_DECK.concat(window.CustomDeck || []));
  state.players.forEach(p => { p.score = 0; p.meeples = 7; });
  state.currentPlayer = 0;
  state.currentTile = drawTile();
  state.legalPositions.clear();
  state.history = [];
  state.areas = {};
  state.nextAreaId = 1;

  const starter = { id: 'START', edges: { N:'field', E:'road', S:'field', W:'road' }, center: null, rotation: 0, areaIds:{} };
  placeTileAt(CENTER, CENTER, starter, { score:false, recordHistory:false, buildAreas:true });
  computeLegalPositions();
  updateUI();
}

function drawTile() {
  return state.deck.length ? cloneTile(state.deck.shift()) : null;
}

function inBounds(r,c){ return r>=0 && c>=0 && r<GRID_SIZE && c<GRID_SIZE; }

function isLegalPlacement(r, c, tile) {
    if (!inBounds(r,c) || state.grid[r][c]) return false;
    
    let hasNeighbor = false;
    const dirs = [['N',-1,0,'S'], ['E',0,1,'W'], ['S',1,0,'N'], ['W',0,-1,'E']];
    
    for (const [dir, dr, dc, opp] of dirs) {
        const rr = r + dr, cc = c + dc;
        if (!inBounds(rr, cc)) continue;
        
        const other = state.grid[rr][cc];
        if (other) {
            hasNeighbor = true;
            // Verificar que los bordes coincidan
            const edge1 = tile.edges[dir];
            const edge2 = other.edges[opp];
            if (edge1 !== edge2) return false;
        }
    }
    return hasNeighbor;
}

function computeLegalPositions(){
  state.legalPositions.clear();
  if(!state.currentTile) return;
  for(let r=0;r<GRID_SIZE;r++) for(let c=0;c<GRID_SIZE;c++){
    if(isLegalPlacement(r,c,state.currentTile)) state.legalPositions.add(`${r},${c}`);
  }
}

// --- Áreas, meeples y cierres (simplificado) ---
function createArea(type){
  const id=`A${state.nextAreaId++}`;
  state.areas[id]={id,type,tiles:new Set(),meeples:new Map(),closed:false};
  return id;
}
function addTileToArea(areaId,r,c,seg){
  state.areas[areaId].tiles.add(`${r},${c}:${seg}`);
}
function canPlaceMeeple(areaId){
  const area=state.areas[areaId];
  let total=0; for(const v of area.meeples.values()) total+=v;
  return total===0;
}
function placeMeeple(areaId,pid){
  const area=state.areas[areaId];
  area.meeples.set(pid,(area.meeples.get(pid)||0)+1);
  state.players[pid].meeples--;
}
function scoreClosure(area) {
    let points = 0;
    if (area.type === 'city') {
        points = 2 * area.tiles.size;
        if (area.shield) points += 2; // Bonus por escudos
    } else if (area.type === 'road') {
        points = area.tiles.size;
    } else if (area.type === 'monastery') {
        points = 9; // Monasterio completo
    }

    // Encontrar jugador(es) con más meeples
    let max = 0;
    const totals = new Map();
    for (const [pid, count] of area.meeples) {
        totals.set(pid, count);
        if (count > max) max = count;
    totals.set(p.id,cnt); if(cnt>max) max=cnt;
  }
  const winners=[...totals.entries()].filter(([_,cnt])=>cnt===max&&cnt>0).map(([pid])=>pid);
  for(const pid of winners) state.players[pid].score+=points;
  for(const [pid,cnt] of area.meeples.entries()) state.players[pid].meeples+=cnt;
  area.closed=true;
}

function placeTileAt(r,c,tile,opts={score:true,recordHistory:true,buildAreas:true,placeMeeple:null}){
  const placed=cloneTile(tile);
  placed.areaIds={N:null,E:null,S:null,W:null,C:null};
  state.grid[r][c]=placed;
  if(opts.placeMeeple && canPlaceMeeple('dummy')){} // simplificado
  if(opts.recordHistory) state.history.push({r,c,tile:cloneTile(placed)});
}

function endTurn(){
  state.currentPlayer=(state.currentPlayer+1)%state.players.length;
  state.currentTile=drawTile();
  computeLegalPositions();
}

function undo(){
  const last=state.history.pop(); if(!last) return;
  state.grid[last.r][last.c]=null;
  state.currentPlayer=last.tile.currentPlayer||0;
  state.deck.unshift(last.tile);
  state.currentTile=cloneTile(last.tile);
  computeLegalPositions();
  updateUI();
}

// --- Persistencia ---
async function saveState(){
  if(state.useLocalStorage) localStorage.setItem('carcassonne_state',JSON.stringify(state));
}
async function loadState(){
  if(state.useLocalStorage){
    const raw=localStorage.getItem('carcassonne_state');
    if(raw) Object.assign(state,JSON.parse(raw));
    updateUI();
  }
}

// --- API expuesta ---
const GameAPI = {
    state,
    newGame,
    saveState,
    loadState,
    undo,
    pass,
    tryPlaceAt,
    rotateCurrent() {
        if (state.currentTile) {
            rotateTile(state.currentTile);
            computeLegalPositions();
            updateUI();
        }
    },
    computeLegalPositions,
    setNetHandlers(handlers) {
        state.net.handlers = handlers;
    }
};

window.GameAPI = GameAPI;  // Exponer API globalmente