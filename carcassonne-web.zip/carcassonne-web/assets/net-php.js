// net-php.js
// Cliente alternativo usando long-polling con PHP

let polling=false;
let roomId=null;

function join(room){
  roomId=room; polling=true;
  GameAPI.state.net.connected=true;
  GameAPI.state.net.roomId=room;
  poll();
}

async function poll(){
  while(polling){
    const res=await fetch(`api/events.php?room=${encodeURIComponent(roomId)}`);
    if(res.ok){
      const events=await res.json();
      for(const ev of events){
        if(ev.type==='move'){
          GameAPI.tryPlaceAt(ev.r,ev.c,null);
        }
      }
      updateUI();
    }
    await new Promise(r=>setTimeout(r,1200));
  }
}

GameAPI.setNetHandlers({
  broadcast(payload){
    fetch(`api/events.php?room=${encodeURIComponent(roomId)}`,{
      method:'POST',headers:{'Content-Type':'application/json'},
