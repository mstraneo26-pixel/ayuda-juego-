// net.js
// Cliente WebSocket para multijugador en tiempo real

let socket=null;

function connect(roomId){
  socket=new WebSocket('ws://localhost:8081');
  socket.addEventListener('open',()=>{
    socket.send(JSON.stringify({type:'join',roomId}));
    GameAPI.state.net.connected=true;
    GameAPI.state.net.roomId=roomId;
    updateUI();
  });
  socket.addEventListener('message',(ev)=>{
    const data=JSON.parse(ev.data);
    if(data.type==='move'){
      // Reproducir movimiento remoto
      GameAPI.tryPlaceAt(data.r,data.c,null);
    }
  });
  socket.addEventListener('close',()=>{GameAPI.state.net.connected=false;updateUI();});
}

GameAPI.setNetHandlers({
  broadcast(payload){
    if(socket && socket.readyState===WebSocket.OPEN){
      socket.send(JSON.stringify({...payload,roomId:GameAPI.state.net.roomId}));
    }
  }
});

document.getElementById('btn-join').addEventListener('click',()=>{
  const room=document.getElementById('room-id').value.trim()||'demo-001';
  connect(room);
});
