// partidas.js
// Gestión de partidas guardadas

async function cargarPartidas() {
    const res = await fetch('api/partidas.php?action=listar');
    const partidas = await res.json();
    const ul = document.getElementById('lista-partidas');
    ul.innerHTML = '';
    partidas.forEach(p => {
        const li = document.createElement('li');
        li.className = 'list-group-item';
        li.innerHTML = `
            <span>${p.nombre} (${p.id}) ${p.finalizada ? '✅' : ''}</span>
            <div class="btn-group btn-group-sm">
                <button class="btn btn-primary" onclick="cargarPartida('${p.id}')">Cargar</button>
                <button class="btn btn-danger" onclick="eliminarPartida('${p.id}')">🗑️</button>
            </div>
        `;
        ul.appendChild(li);
    });
}

async function crearPartida() {
    const nombre = prompt('Nombre de la partida:');
    if (!nombre) return;
    
    const id = 'p' + Date.now();
    const partida = {
        id, 
        nombre,
        jugadores: [GameAPI.state.players[0].name, GameAPI.state.players[1].name],
        estado: GameAPI.state,
        fecha: new Date().toISOString(),
        finalizada: false
    };

    try {
        await fetch('api/partidas.php?action=guardar', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(partida)
        });
        cargarPartidas();
    } catch (err) {
        alert('Error al guardar la partida');
        console.error(err);
    }
}

async function cargarPartida(id) {
    try {
        const res = await fetch(`api/partidas.php?action=cargar&id=${id}`);
        const data = await res.json();
        
        // Restaurar estado del juego
        Object.assign(GameAPI.state, {
            ...data.estado,
            currentTile: data.estado.currentTile ? cloneTile(data.estado.currentTile) : null,
            deck: (data.estado.deck || []).map(cloneTile),
            legalPositions: new Set(data.estado.legalPositions || []),
            net: data.estado.net || { connected: false, roomId: null }
        });

        // Recomputar posiciones legales y actualizar UI
        GameAPI.computeLegalPositions();
        updateUI();
    } catch (err) {
        alert('Error al cargar la partida');
        console.error(err);
    }
}

async function eliminarPartida(id) {
    if (!confirm('¿Seguro que quieres eliminar esta partida?')) return;
    
    try {
        await fetch(`api/partidas.php?action=eliminar&id=${id}`, { method: 'DELETE' });
        cargarPartidas();
    } catch (err) {
        alert('Error al eliminar la partida');
        console.error(err);
    }
}

// Inicializar al cargar
window.addEventListener('DOMContentLoaded', cargarPartidas);