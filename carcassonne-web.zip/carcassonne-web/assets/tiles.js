// tiles.js
// Definición del mazo base y utilidades de fichas

// Mazo completo basado en las losetas originales de Carcassonne
const TEMPLATE_DECK = [
    // Monasterios
    { 
        id: 'A', 
        edges: { N:'field', E:'field', S:'field', W:'field' }, 
        center: 'monastery', 
        count: 2,
        imageId: 'A'
    },
    
    // Ciudades
    { 
        id: 'B', 
        edges: { N:'city', E:'city', S:'city', W:'city' }, 
        center: null, 
        count: 4,
        shield: true,
        imageId: 'B'
    },
    { 
        id: 'C', 
        edges: { N:'city', E:'city', S:'field', W:'field' }, 
        center: null, 
        count: 1,
        imageId: 'C'
    },
    { 
        id: 'D', 
        edges: { N:'city', E:'field', S:'field', W:'city' }, 
        center: null, 
        count: 4,
        imageId: 'D'
    },
    
    // Caminos
    { 
        id: 'F', 
        edges: { N:'field', E:'road', S:'field', W:'road' }, 
        center: null, 
        count: 2,
        imageId: 'F'
    },
    { 
        id: 'G', 
        edges: { N:'road', E:'road', S:'road', W:'road' }, 
        center: null, 
        count: 1,
        imageId: 'G'
    },
    { 
        id: 'H', 
        edges: { N:'field', E:'road', S:'road', W:'road' }, 
        center: null, 
        count: 3,
        imageId: 'H'
    },
    
    // Ciudades con caminos
    { 
        id: 'I', 
        edges: { N:'city', E:'road', S:'road', W:'field' }, 
        center: null, 
        count: 2,
        imageId: 'I'
    },
    { 
        id: 'J', 
        edges: { N:'city', E:'road', S:'field', W:'road' }, 
        center: null, 
        count: 3,
        imageId: 'J'
    },
    { 
        id: 'K', 
        edges: { N:'city', E:'city', S:'road', W:'field' }, 
        center: null, 
        count: 3,
        shield: true,
        imageId: 'K'
    },
    
    // Ciudades especiales
    { 
        id: 'M', 
        edges: { N:'city', E:'city', S:'field', W:'city' }, 
        center: null, 
        count: 3,
        shield: true,
        imageId: 'M'
    },
    { 
        id: 'N', 
        edges: { N:'city', E:'field', S:'field', W:'field' }, 
        center: null, 
        count: 3,
        imageId: 'N'
    },
    
    // Caminos con ciudad
    { 
        id: 'P', 
        edges: { N:'city', E:'road', S:'road', W:'road' }, 
        center: null, 
        count: 2,
        imageId: 'P'
    },
    { 
        id: 'Q', 
        edges: { N:'field', E:'road', S:'road', W:'field' }, 
        center: 'monastery', 
        count: 3,
        imageId: 'Q'
    },
    
    // Ficha inicial
    { 
        id: 'START', 
        edges: { N:'field', E:'road', S:'field', W:'road' }, 
        center: null, 
        count: 1,
        imageId: 'F'  // Usa la imagen de la ficha F que es similar
    }
];

// Expandir TEMPLATE_DECK -> BASE_DECK (cada entry repetida 'count' veces)
const BASE_DECK = [];
for (const t of TEMPLATE_DECK) {
  const cnt = Number.isInteger(t.count) && t.count > 0 ? t.count : 1;
  for (let i = 0; i < cnt; i++) {
    // Crear una copia simple sin 'count' para el mazo real
    BASE_DECK.push({ id: `${t.id}${cnt>1?'-'+(i+1):''}`, edges: { ...t.edges }, center: t.center || null });
  }
}

// Rotar un tile 90° clockwise
function rotateTile(tile) {
  const { N, E, S, W } = tile.edges;
  tile.edges = { N: W, E: N, S: E, W: S };
  tile.rotation = ((tile.rotation || 0) + 90) % 360;
  return tile;
}

// Clonar tile
function cloneTile(t) {
  return {
    id: t.id,
    edges: { ...t.edges },
    center: t.center || null,
    rotation: t.rotation || 0,
    areaIds: t.areaIds ? { ...t.areaIds } : {}
  };
}

// Barajar mazo
function shuffleDeck(deck) {
  const d = deck.map(cloneTile);
  for (let i = d.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [d[i], d[j]] = [d[j], d[i]];
  }
  return d;
}

// Compatibilidad de bordes
function edgesMatch(a, b) {
  return a === b;
}

export { BASE_DECK, rotateTile, cloneTile, shuffleDeck, edgesMatch };
