// ui.js
// Renderizado del tablero, controles de UI y editor de tiles

const boardEl = document.getElementById('board');
const turnLabel = document.getElementById('turn-label');
const score0 = document.getElementById('score-0');
const score1 = document.getElementById('score-1');
const deckCount = document.getElementById('deck-count');
const previewEl = document.getElementById('current-tile');
const chkMeeple = document.getElementById('chk-place-meeple');
const btnUndo = document.getElementById('btn-undo');
const btnToggleLegal = document.getElementById('btn-toggle-legal');
const netStatus = document.getElementById('net-status');

document.getElementById('btn-new').addEventListener('click', () => GameAPI.newGame());
document.getElementById('btn-save').addEventListener('click', () => GameAPI.saveState());
document.getElementById('btn-load').addEventListener('click', () => GameAPI.loadState());
document.getElementById('btn-rotate').addEventListener('click', () => GameAPI.rotateCurrent());
document.getElementById('btn-pass').addEventListener('click', () => GameAPI.pass());
btnUndo.addEventListener('click', () => GameAPI.undo());

let showLegal = true;
btnToggleLegal.addEventListener('click', () => { showLegal = !showLegal; renderLegalHints(); });

function buildBoard(gridSize) {
  boardEl.innerHTML = '';
  for (let r = 0; r < gridSize; r++) {
    for (let c = 0; c < gridSize; c++) {
      const cell = document.createElement('div');
      cell.className = 'cell';
      cell.dataset.r = r;
      cell.dataset.c = c;
      cell.addEventListener('click', onCellClick);
      boardEl.appendChild(cell);
    }
  }
}

function renderCell(r, c, tile) {
  const idx = r * getGridSize() + c;
  const cell = boardEl.children[idx];
  cell.innerHTML = '';
  if (!tile) return;
  const face = makeTileFace(tile);
  // Meeples
  for (const seg of ['N','E','S','W','C']) {
    const areaId = tile.areaIds && tile.areaIds[seg];
    if (!areaId) continue;
    const area = GameAPI.state.areas[areaId];
    if (!area) continue;
    for (const [pid, cnt] of area.meeples.entries()) {
      if (cnt > 0) {
        const m = document.createElement('div');
        m.className = `meeple p${pid}`;
        const pos = { N:['50%','12%'], S:['50%','88%'], E:['88%','50%'], W:['12%','50%'], C:['50%','50%'] }[seg];
        m.style.left = pos[0]; m.style.top = pos[1];
        face.appendChild(m);
      }
    }
  }
  cell.appendChild(face);
}

function makeTileFace(tile) {
  const face = document.createElement('div');
  face.className = 'tile-face';
  
  if (tile.imageId) {
    // Si tiene imageId, usar la imagen de la loseta
    const img = document.createElement('img');
    img.className = 'tile-image';
    img.src = `assets/images/tiles/${tile.imageId}.png`;
    img.alt = `Loseta ${tile.id}`;
    face.appendChild(img);
    
    // Aplicar rotación si existe
    if (tile.rotation) {
      face.parentElement?.setAttribute('data-rotation', tile.rotation.toString());
    }
  } else {
    // Fallback al renderizado original si no hay imagen
    const n = document.createElement('div'); n.className = `edge-n edge-${tile.edges.N}`;
    const e = document.createElement('div'); e.className = `edge-e edge-${tile.edges.E}`;
    const s = document.createElement('div'); s.className = `edge-s edge-${tile.edges.S}`;
    const w = document.createElement('div'); w.className = `edge-w edge-${tile.edges.W}`;
    const c = document.createElement('div'); c.className = `center ${tile.center==='monastery'?'center-monastery':''}`;
    face.append(n,e,s,w,c);
  }
  
  return face;
}

function renderPreview(tile) {
  previewEl.innerHTML = '';
  if (!tile) { previewEl.textContent = 'Sin fichas'; return; }
  previewEl.appendChild(makeTileFace(tile));
}

function onCellClick(e) {
  const r = parseInt(e.currentTarget.dataset.r,10);
  const c = parseInt(e.currentTarget.dataset.c,10);
  const placeMeepleSeg = chkMeeple.checked ? prompt('Segmento (N/E/S/W/C):') : null;
  GameAPI.tryPlaceAt(r,c, placeMeepleSeg);
}

function markCellIllegal(r,c){
  const idx = r*getGridSize()+c;
  const cell = boardEl.children[idx];
  cell.classList.add('illegal');
  setTimeout(()=>cell.classList.remove('illegal'),400);
}

function getGridSize(){
  return parseInt(getComputedStyle(document.documentElement).getPropertyValue('--grid-size'),10) || 13;
}

function renderLegalHints(){
  const size=getGridSize();
  for(let r=0;r<size;r++) for(let c=0;c<size;c++){
    const idx=r*size+c;
    const cell=boardEl.children[idx];
    const key=`${r},${c}`;
    cell.classList.toggle('legal', showLegal && GameAPI.state.legalPositions.has(key) && !GameAPI.state.grid[r][c]);
  }
}

function updateUI(){
  const {grid,players,currentPlayer,currentTile,deck,net}=GameAPI.state;
  turnLabel.textContent=`Turno: ${players[currentPlayer].name} | Meeples: ${players[currentPlayer].meeples}`;
  score0.textContent=players[0].score;
  score1.textContent=players[1].score;
  deckCount.textContent=deck.length;
  const size=getGridSize();
  for(let r=0;r<size;r++) for(let c=0;c<size;c++) renderCell(r,c,grid[r][c]);
  renderPreview(currentTile);
  renderLegalHints();
  netStatus.textContent=net.connected?`Online (${net.roomId})`:'Offline';
}

setUIHooks({updateUI,markCellIllegal});
buildBoard(getGridSize());
GameAPI.newGame();

// Editor de tiles
const tileTemplates = [
  {
    name: "Camino Recto",
    tile: { N:'road', S:'road', E:'field', W:'field' }
  },
  {
    name: "Camino Curvo",
    tile: { N:'road', E:'road', S:'field', W:'field' }
  },
  {
    name: "Ciudad Simple",
    tile: { N:'city', E:'field', S:'field', W:'field' }
  },
  {
    name: "Ciudad Doble",
    tile: { N:'city', E:'city', S:'field', W:'field' }
  },
  {
    name: "Monasterio",
    tile: { N:'field', E:'field', S:'field', W:'field' },
    center: 'monastery'
  },
  {
    name: "Ciudad y Camino",
    tile: { N:'city', E:'field', S:'road', W:'road' }
  }
];

const tileForm = document.getElementById('tile-form');
const tilePreview = document.getElementById('tile-preview');
const templatesContainer = document.getElementById('tile-templates');

// Inicializar plantillas
function initTileTemplates() {
  templatesContainer.innerHTML = '';
  tileTemplates.forEach((template, idx) => {
    const container = document.createElement('div');
    container.className = 'tile-template';
    
    const preview = document.createElement('div');
    preview.className = 'tile preview';
    preview.appendChild(makeTileFace({
      edges: template.tile,
      center: template.center || null
    }));
    
    const label = document.createElement('div');
    label.className = 'tile-label';
    label.textContent = template.name;
    
    container.append(preview, label);
    container.addEventListener('click', () => useTemplate(template));
    templatesContainer.appendChild(container);
  });
}

function useTemplate(template) {
  const form = document.forms['tile-form'];
  form.N.value = template.tile.N;
  form.E.value = template.tile.E;
  form.S.value = template.tile.S;
  form.W.value = template.tile.W;
  form.center.value = template.center || '';
  updatePreview();
}

function updatePreview() {
  const data = Object.fromEntries(new FormData(tileForm));
  const tile = {
    edges: { N:data.N, E:data.E, S:data.S, W:data.W },
    center: data.center || null
  };
  tilePreview.innerHTML = '';
  tilePreview.appendChild(makeTileFace(tile));
}

// Event Listeners
tileForm.addEventListener('change', updatePreview);

document.getElementById('btn-add-tile').addEventListener('click', () => {
  const data = Object.fromEntries(new FormData(tileForm));
  if (!data.id) {
    alert('Por favor ingresa un ID para la loseta');
    return;
  }
  
  const tile = {
    id: data.id,
    edges: { N:data.N, E:data.E, S:data.S, W:data.W },
    center: data.center || null
  };
  
  window.CustomDeck = window.CustomDeck || [];
  window.CustomDeck.push(tile);
  alert(`Loseta ${data.id} añadida al mazo personalizado`);
});

document.getElementById('btn-random-tile').addEventListener('click', () => {
  const template = tileTemplates[Math.floor(Math.random() * tileTemplates.length)];
  useTemplate(template);
});

document.getElementById('btn-clear-editor').addEventListener('click', () => {
  tileForm.reset();
  updatePreview();
});

document.getElementById('btn-export-deck').addEventListener('click', () => {
  const deck = window.CustomDeck || [];
  const blob = new Blob([JSON.stringify(deck, null, 2)], {type: 'application/json'});
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'custom_deck.json';
  a.click();
});

// Inicializar editor
initTileTemplates();
updatePreview();
